package handler

import (
	"fmt"
	"net"

	"strings"

	"github.com/codecrafters-io/http-server-starter-go/app/modals"
	"github.com/codecrafters-io/http-server-starter-go/app/pkg/config"
	"github.com/codecrafters-io/http-server-starter-go/app/utils"
)

func echoHandler(conn net.Conn, req modals.Request) {
	tokens := strings.Split(req.Path, "/")
	var res modals.Response
	echoBody := tokens[2] + "\n"
	res = modals.Response{
		StatusCode: config.OK,
		Body:       echoBody,
		Headers: map[string]string{
			"Content-Type":   config.TextContentType,
			"Content-Length": fmt.Sprintf("%d", len(tokens[2])),
		},
	}
	utils.WriteResponse(conn, res)

}
