package handler

import (
	"fmt"
	"net"
	"os"
	"path/filepath"

	"strings"

	"errors"

	"github.com/codecrafters-io/http-server-starter-go/app/modals"
	"github.com/codecrafters-io/http-server-starter-go/app/pkg/config"
	"github.com/codecrafters-io/http-server-starter-go/app/utils"
)

func fileHanlder(conn net.Conn, req modals.Request, baseDir string) {
	tokens := strings.Split(req.Path, "/")
	var res modals.Response
	filePath := tokens[2]

	actualFile := filepath.Join(baseDir, "app/tmp", filePath)
	file, err := os.Open(actualFile)

	if errors.Is(err, os.ErrNotExist) {
		fmt.Println(err)
		res = modals.Response{
			StatusCode: config.NotFound,
		}
	} else {
		data := make([]byte, 1024)
		count, err := file.Read(data)
		if err != nil {
			fmt.Println("failed to real data: ", err.Error())
		}
		fileData := string(data[:count])
		res = modals.Response{
			StatusCode: config.OK,
			Body:       fileData,
			Headers: map[string]string{
				"Content-Type":   config.FileContentType,
				"Content-Length": fmt.Sprintf("%d", count),
			},
		}
	}
	utils.WriteResponse(conn, res)

}
