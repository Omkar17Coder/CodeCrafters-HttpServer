package handler

import (
	"net"

	"github.com/codecrafters-io/http-server-starter-go/app/http"
	"github.com/codecrafters-io/http-server-starter-go/app/modals"
	"github.com/codecrafters-io/http-server-starter-go/app/pkg/config"
	"github.com/codecrafters-io/http-server-starter-go/app/utils"
)

func defaultHandler(context http.) {
	var res modals.Response
	res = modals.Response{
		StatusCode: config.OK,
	}
	utils.WriteResponse(conn, res)
}
func not_found_handler(conn net.Conn) {
	var res modals.Response
	res = modals.Response{
		StatusCode: config.NotFound,
	}
	utils.WriteResponse(conn, res)
}
