package handler

import (
	"net"

	"strings"

	"fmt"

	"github.com/codecrafters-io/http-server-starter-go/app/modals"
	"github.com/codecrafters-io/http-server-starter-go/app/pkg/config"
	"github.com/codecrafters-io/http-server-starter-go/app/utils"
)

func user_agentHandler(conn net.Conn, req modals.Request) {
	tokens := strings.Split(req.Path, "/")
	var res modals.Response
	echoBody := tokens[2] + "\n"
	userAgent := req.Headers["User-Agent"]
	res = modals.Response{
		StatusCode: config.OK,
		Body:       echoBody,
		Headers: map[string]string{
			"Content-Type":   config.TextContentType,
			"Content-Length": fmt.Sprintf("%d", len(userAgent)),
		},
	}
	utils.WriteResponse(conn, res)
}
